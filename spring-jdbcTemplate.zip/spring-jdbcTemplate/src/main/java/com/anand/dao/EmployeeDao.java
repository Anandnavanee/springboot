package com.anand.dao;

import java.util.List;

import com.anand.model.Employee;

public interface EmployeeDao {

	int save(Employee employee);
	
	List<Employee> getAll();
	
	Employee getById(int id);
	
	int update(Employee employee,int id);
}
