package com.anand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.anand.dao.EmployeeDao;
import com.anand.model.Employee;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeDao edao;
	
	@PostMapping("/employees")
	public String saveEmployee(@RequestBody Employee employee) {
		return edao.save(employee) + " no of rows inserted";
	}
	
	@GetMapping("/employees")
	public List<Employee> getEmployees(){
		return edao.getAll();
	}
	
	@GetMapping("/employees/{id}")
	public Employee getByEmployeeId(@PathVariable int id) {
		return edao.getById(id);
	}
	
	@PutMapping("/employees/{id}")
	public String updateEmployee(@RequestBody Employee employee,@PathVariable int id) {
		return edao.update(employee, id) + " no of rows updated";
	}
}
