package com.anand.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anand.exception.ResourceNotFoundException;
import com.anand.model.User;
import com.anand.repository.UserRepository;

@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/users")
	public List<User> getAllUser() {
		return userRepository.findAll();
	}
	@PostMapping("/users")
	public User createUser(@Validated  @RequestBody User user) {
		return userRepository.save(user);
	}
	
	@PutMapping("/user/{id}")
	public ResponseEntity<User> 
	updateUser(@PathVariable(value="id") Long userId,@Validated @RequestBody User userDetails)throws ResourceNotFoundException{
		User user = userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User not found "+ userId));
		user.setEmailId(userDetails.getEmailId());
		user.setFirstName(userDetails.getFirstName());
		user.setLastName(userDetails.getLastName());
		user.setUpdatedAt(new Date());
		final User updatedUser = userRepository.save(user);
		return ResponseEntity.ok(updatedUser);
	}
}
